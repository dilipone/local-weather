import GObject from 'gi://GObject';
import St from 'gi://St';
import GLib from 'gi://GLib';
import Soup from 'gi://Soup';
import Clutter from 'gi://Clutter';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';

// Coordinates for Palakkad and surrounding local areas
const LOCATIONS = [
    { name: 'Palakkad', lat: 10.7867, lon: 76.6548 },
    { name: 'Kozhinjampara', lat: 10.7384, lon: 76.8338 }, //
    { name: 'Ottapalam', lat: 10.7727, lon: 76.3813 },
    { name: 'Mannarkkad', lat: 10.9892, lon: 76.4593 },
    { name: 'Chittur', lat: 10.6975, lon: 76.7196 },
    { name: 'Alathur', lat: 10.6437, lon: 76.5441 },
    { name: 'Pattambi', lat: 10.8062, lon: 76.1963 },
    { name: 'Shoranur', lat: 10.7634, lon: 76.2730 }
];

// Map Open-Meteo WMO Codes to GNOME standard system icons
function getWeatherIcon(wmoCode) {
    if (wmoCode === 0) return 'weather-clear-symbolic';
    if (wmoCode === 1 || wmoCode === 2) return 'weather-few-clouds-symbolic';
    if (wmoCode === 3) return 'weather-overcast-symbolic';
    if (wmoCode === 45 || wmoCode === 48) return 'weather-fog-symbolic';
    if ([51, 53, 55, 56, 57].includes(wmoCode)) return 'weather-showers-scattered-symbolic';
    if ([61, 63, 65, 66, 67, 80, 81, 82].includes(wmoCode)) return 'weather-showers-symbolic';
    if ([71, 73, 75, 77, 85, 86].includes(wmoCode)) return 'weather-snow-symbolic';
    if ([95, 96, 99].includes(wmoCode)) return 'weather-storm-symbolic';
    return 'weather-clear-symbolic';
}

const WeatherIndicator = GObject.registerClass(
class WeatherIndicator extends PanelMenu.Button {
    _init() {
        super._init(0.0, 'Palakkad Weather');

        // Layout container for the top panel
        let box = new St.BoxLayout({
            vertical: false,
            style_class: 'panel-status-menu-box'
        });

        // Weather Icon
        this._icon = new St.Icon({
            icon_name: 'weather-clear-symbolic',
            style_class: 'system-status-icon',
        });
        box.add_child(this._icon);

        // Weather Text Label
        this._label = new St.Label({
            text: 'Loading...',
            y_align: Clutter.ActorAlign.CENTER,
            margin_left: 6
        });
        box.add_child(this._label);

        this.add_child(box);

        // HTTP Session for API calls
        this._session = new Soup.Session();
        this._currentLocationIndex = 0;

        this._buildMenu();

        // Initial fetch and 30-minute update loop
        this._updateWeather();
        this._timeoutId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 1800, () => {
            this._updateWeather();
            return GLib.SOURCE_CONTINUE;
        });
    }

    _buildMenu() {
        let section = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(section);

        // Add local Palakkad areas to dropdown
        LOCATIONS.forEach((loc, index) => {
            let item = new PopupMenu.PopupMenuItem(loc.name);
            item.connect('activate', () => {
                this._currentLocationIndex = index;
                this._label.text = 'Updating...';
                this._updateWeather();
            });
            section.addMenuItem(item);
        });

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        let refreshItem = new PopupMenu.PopupMenuItem('🔄 Refresh Weather Now');
        refreshItem.connect('activate', () => {
            this._label.text = 'Updating...';
            this._updateWeather();
        });
        this.menu.addMenuItem(refreshItem);
    }

    async _updateWeather() {
        const location = LOCATIONS[this._currentLocationIndex];
        // Request temperature and weather code for the specific local area
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${location.lat}&longitude=${location.lon}&current=temperature_2m,weather_code&timezone=Asia%2FKolkata`;

        try {
            let message = Soup.Message.new('GET', url);
            let bytes = await this._session.send_and_read_async(message, GLib.PRIORITY_DEFAULT, null);

            if (message.status_code !== 200) {
                this._label.text = 'API Error';
                return;
            }

            // Decode and parse the JSON response
            let decoder = new TextDecoder('utf-8');
            let data = JSON.parse(decoder.decode(bytes.toArray()));

            let temp = Math.round(data.current.temperature_2m);
            let code = data.current.weather_code;

            this._icon.icon_name = getWeatherIcon(code);
            this._label.text = `${location.name} ${temp}°C`;
        } catch (e) {
            console.error(e);
            this._label.text = 'Offline';
        }
    }

    destroy() {
        // Cleanup loop and HTTP session to prevent memory leaks when extension disables
        if (this._timeoutId) {
            GLib.source_remove(this._timeoutId);
            this._timeoutId = null;
        }
        if (this._session) {
            this._session.abort();
            this._session = null;
        }
        super.destroy();
    }
});

export default class WeatherExtension extends Extension {
    enable() {
        this._indicator = new WeatherIndicator();
        Main.panel.addToStatusArea(this.uuid, this._indicator);
    }

    disable() {
        if (this._indicator) {
            this._indicator.destroy();
            this._indicator = null;
        }
    }
}
