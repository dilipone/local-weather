import GObject from 'gi://GObject';
import St from 'gi://St';
import GLib from 'gi://GLib';
import Soup from 'gi://Soup';
import Clutter from 'gi://Clutter';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';

// Coordinates for Palakkad and surrounding local areas
const LOCATIONS = [
    { name: 'Palakkad', lat: 10.7867, lon: 76.6548 },
    { name: 'Kozhinjampara', lat: 10.7384, lon: 76.8338 },
    { name: 'Ottapalam', lat: 10.7727, lon: 76.3813 },
    { name: 'Mannarkkad', lat: 10.9892, lon: 76.4593 },
    { name: 'Chittur', lat: 10.6975, lon: 76.7196 },
    { name: 'Alathur', lat: 10.6437, lon: 76.5441 },
    { name: 'Pattambi', lat: 10.8062, lon: 76.1963 },
    { name: 'Shoranur', lat: 10.7634, lon: 76.2730 }
];

// Map Open-Meteo WMO Codes to GNOME standard system icons
function getWeatherIcon(wmoCode) {
    if (wmoCode === 0) return 'weather-clear-symbolic';
    if (wmoCode === 1 || wmoCode === 2) return 'weather-few-clouds-symbolic';
    if (wmoCode === 3) return 'weather-overcast-symbolic';
    if (wmoCode === 45 || wmoCode === 48) return 'weather-fog-symbolic';
    if ([51, 53, 55, 56, 57].includes(wmoCode)) return 'weather-showers-scattered-symbolic';
    if ([61, 63, 65, 66, 67, 80, 81, 82].includes(wmoCode)) return 'weather-showers-symbolic';
    if ([71, 73, 75, 77, 85, 86].includes(wmoCode)) return 'weather-snow-symbolic';
    if ([95, 96, 99].includes(wmoCode)) return 'weather-storm-symbolic';
    return 'weather-clear-symbolic';
}

// Map WMO Codes to readable text
function getWeatherDescription(wmoCode) {
    if (wmoCode === 0) return 'Clear Skies';
    if (wmoCode === 1 || wmoCode === 2) return 'Partly Cloudy';
    if (wmoCode === 3) return 'Overcast';
    if (wmoCode === 45 || wmoCode === 48) return 'Foggy';
    if ([51, 53, 55, 56, 57].includes(wmoCode)) return 'Drizzle';
    if ([61, 63, 65, 66, 67].includes(wmoCode)) return 'Rainy';
    if ([80, 81, 82].includes(wmoCode)) return 'Showers';
    if ([71, 73, 75, 77, 85, 86].includes(wmoCode)) return 'Snow';
    if ([95, 96, 99].includes(wmoCode)) return 'Thunderstorms';
    return 'Variable';
}

// Format date into day names (Today, Thu, Fri, etc.)
function formatDay(dateStr, index) {
    if (index === 0) return 'Today';
    let parts = dateStr.split('-');
    let date = new Date(parts[0], parts[1] - 1, parts[2]);
    return date.toLocaleDateString('en-US', { weekday: 'short' });
}

const WeatherIndicator = GObject.registerClass(
class WeatherIndicator extends PanelMenu.Button {
    _init() {
        super._init(0.0, 'Palakkad Weather');

        // Top bar container
        let box = new St.BoxLayout({
            vertical: false,
            style_class: 'panel-status-menu-box'
        });

        // Top bar icon
        this._icon = new St.Icon({
            icon_name: 'weather-clear-symbolic',
            style_class: 'system-status-icon',
        });
        box.add_child(this._icon);

        // Top bar label
        this._label = new St.Label({
            text: 'Loading...',
            y_align: Clutter.ActorAlign.CENTER,
            margin_left: 6
        });
        box.add_child(this._label);
        this.add_child(box);

        this._normalText = 'Loading...';
        this._hoverText = 'Fetching forecast...';

        // Hover preview
        this.connect('enter-event', () => {
            this._label.text = this._hoverText;
            return Clutter.EVENT_PROPAGATE;
        });

        this.connect('leave-event', () => {
            this._label.text = this._normalText;
            return Clutter.EVENT_PROPAGATE;
        });

        this._session = new Soup.Session();
        this._currentLocationIndex = 0;

        // Build Menu Sections
        this._headerSection = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this._headerSection);

        this._forecastSection = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this._forecastSection);

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        // Submenu for choosing areas
        this._locationsMenu = new PopupMenu.PopupSubMenuMenuItem('📍 Switch Location');
        LOCATIONS.forEach((loc, index) => {
            let item = new PopupMenu.PopupMenuItem(loc.name);
            item.connect('activate', () => {
                this._currentLocationIndex = index;
                this._normalText = 'Updating...';
                this._label.text = this._normalText;
                this._updateWeather();
            });
            this._locationsMenu.menu.addMenuItem(item);
        });
        this.menu.addMenuItem(this._locationsMenu);

        // Refresh action
        let refreshItem = new PopupMenu.PopupMenuItem('🔄 Refresh Now');
        refreshItem.connect('activate', () => {
            this._normalText = 'Updating...';
            this._label.text = this._normalText;
            this._updateWeather();
        });
        this.menu.addMenuItem(refreshItem);

        // Fetch data
        this._updateWeather();
        this._timeoutId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 1800, () => {
            this._updateWeather();
            return GLib.SOURCE_CONTINUE;
        });
    }

    async _updateWeather() {
        const location = LOCATIONS[this._currentLocationIndex];
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${location.lat}&longitude=${location.lon}&current=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=Asia%2FKolkata`;

        try {
            let message = Soup.Message.new('GET', url);
            let bytes = await this._session.send_and_read_async(message, GLib.PRIORITY_DEFAULT, null);

            if (message.status_code !== 200) {
                this._normalText = 'API Error';
                this._label.text = this._normalText;
                return;
            }

            let decoder = new TextDecoder('utf-8');
            let data = JSON.parse(decoder.decode(bytes.toArray()));

            let temp = Math.round(data.current.temperature_2m);
            let code = data.current.weather_code;
            let maxTemp = Math.round(data.daily.temperature_2m_max[0]);
            let minTemp = Math.round(data.daily.temperature_2m_min[0]);
            let desc = getWeatherDescription(code);

            // Update top bar
            this._icon.icon_name = getWeatherIcon(code);
            this._normalText = `${location.name} ${temp}°C`;
            this._hoverText = `${desc} | H: ${maxTemp}°C / L: ${minTemp}°C`;
            this._label.text = this.has_pointer ? this._hoverText : this._normalText;

            // Render Header
            this._headerSection.removeAll();
            let headerItem = new PopupMenu.PopupMenuItem(`📍 ${location.name} — ${temp}°C (${desc})`, { reactive: false });
            this._headerSection.addMenuItem(headerItem);

            // Render 7-Day Forecast
            this._forecastSection.removeAll();
            let daysCount = Math.min(data.daily.time.length, 7);

            for (let i = 0; i < daysCount; i++) {
                let dayName = formatDay(data.daily.time[i], i);
                let dayCode = data.daily.weather_code[i];
                let dayMax = Math.round(data.daily.temperature_2m_max[i]);
                let dayMin = Math.round(data.daily.temperature_2m_min[i]);
                let dayDesc = getWeatherDescription(dayCode);

                let forecastItem = new PopupMenu.PopupBaseMenuItem({ reactive: false });
                
                let rowBox = new St.BoxLayout({
                    vertical: false,
                    x_expand: true,
                    style: 'spacing: 12px; padding: 3px 0;'
                });

                // Day Label (Fixed width for alignment)
                let dayLabel = new St.Label({
                    text: dayName,
                    style: 'width: 55px; font-weight: bold;',
                    y_align: Clutter.ActorAlign.CENTER
                });
                rowBox.add_child(dayLabel);

                // Weather Icon
                let icon = new St.Icon({
                    icon_name: getWeatherIcon(dayCode),
                    style_class: 'system-status-icon',
                    icon_size: 16
                });
                rowBox.add_child(icon);

                // Min / Max Temps
                let tempLabel = new St.Label({
                    text: `${dayMax}° / ${dayMin}°C`,
                    style: 'width: 80px;',
                    y_align: Clutter.ActorAlign.CENTER
                });
                rowBox.add_child(tempLabel);

                // Sky Condition
                let descLabel = new St.Label({
                    text: dayDesc,
                    y_align: Clutter.ActorAlign.CENTER,
                    x_expand: true
                });
                rowBox.add_child(descLabel);

                forecastItem.add_child(rowBox);
                this._forecastSection.addMenuItem(forecastItem);
            }

        } catch (e) {
            console.error(e);
            this._normalText = 'Offline';
            this._label.text = this._normalText;
        }
    }

    destroy() {
        if (this._timeoutId) {
            GLib.source_remove(this._timeoutId);
            this._timeoutId = null;
        }
        if (this._session) {
            this._session.abort();
            this._session = null;
        }
        super.destroy();
    }
});

export default class WeatherExtension extends Extension {
    enable() {
        this._indicator = new WeatherIndicator();
        Main.panel.addToStatusArea(this.uuid, this._indicator);
    }

    disable() {
        if (this._indicator) {
            this._indicator.destroy();
            this._indicator = null;
        }
    }
}
